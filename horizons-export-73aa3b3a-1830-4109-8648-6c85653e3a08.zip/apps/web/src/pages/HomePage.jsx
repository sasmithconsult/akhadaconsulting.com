import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, Building2, HardHat, Landmark, CheckCircle2, PlayCircle, Mic, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HomePage = () => {
  // Mobile Menu State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Podcast State Management
  const [episodes, setEpisodes] = useState([]);
  const [loadingPodcast, setLoadingPodcast] = useState(true);
  const [podcastError, setPodcastError] = useState(false);

  // Mobile Menu Helpers
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  // Smooth scroll helper (updated to close the mobile menu on click)
  const scrollToSection = id => {
    closeMobileMenu();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };

  // Fetch Podcast Data on Component Mount
  useEffect(() => {
    const fetchPodcast = async () => {
      try {
        const RSS_URL = 'https://feeds.buzzsprout.com/2465553.rss';
        const API_URL = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(RSS_URL)}`;
        
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        
        if (data.status === 'ok') {
          // Keep only the 3 newest episodes
          setEpisodes(data.items.slice(0, 3));
        } else {
          throw new Error('Failed to parse feed');
        }
      } catch (err) {
        console.error('Error fetching podcast feed:', err);
        setPodcastError(true);
      } finally {
        setLoadingPodcast(false);
      }
    };

    fetchPodcast();
  }, []);

  // Helper function to strip HTML tags and truncate text for podcast descriptions
  const formatDescription = (htmlString) => {
    const strippedString = htmlString.replace(/(<([^>]+)>)/gi, "");
    if (strippedString.length <= 140) return strippedString;
    return strippedString.substring(0, 140).trim() + '...';
  };

  // Helper function to format the publication date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <>
      <Helmet>
        <title>AKHADA | Building Organizations That Don't Depend on the Founder</title>
        <meta name="description" content="Principal advisory for founder-led service businesses building stronger leadership, clearer ownership, and operating capacity beyond the founder." />
        <meta name="keywords" content="Founder-led business, Operational Advisory, Leadership, Scaling Business, Business Systems, Organization Building" />

        {/* AEO Schema Injection */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "AKHADA",
              "image": "https://i.postimg.cc/8504e7/logo.png",
              "description": "Principal advisory for founder-led service businesses building stronger leadership, clearer ownership, and operating capacity beyond the founder.",
              "founder": {
                "@type": "Person",
                "name": "Scott Smith"
              },
              "knowsAbout": [
                "Operational Advisory",
                "Leadership Structure",
                "Founder Transition",
                "Business Systems",
                "Organizational Scaling"
              ]
            }
          `}
        </script>
      </Helmet>

      <div className="bg-black text-white font-sans overflow-x-hidden w-full">
        {/* Navigation */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-[hsl(var(--accent))]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <img src="https://i.postimg.cc/fRNhKJFC/logo.png" alt="AKHADA Logo" className="h-12 w-auto object-contain" />
                <span className="text-xl font-bold tracking-wider text-white hidden sm:block">
                  AKHADA
                </span>
              </div>
              
              {/* Desktop Menu */}
              <div className="hidden lg:flex items-center gap-8">
                <button onClick={() => scrollToSection('hero')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Home</button>
                <button onClick={() => scrollToSection('growth')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">The Problem</button>
                <button onClick={() => scrollToSection('what-we-build')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">What We Build</button>
                <button onClick={() => scrollToSection('how-we-work')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">How We Work</button>
                <button onClick={() => scrollToSection('philosophy')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Philosophy</button>
                <button onClick={() => scrollToSection('podcast')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Podcast</button>
                <button onClick={() => window.location.href='/affordable-housing-advisory'} className="text-sm font-medium hover:text-[#4fd1c5] transition-colors duration-200">Housing Advisory</button>
                <button onClick={() => scrollToSection('contact')} className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Contact</button>
              </div>

              {/* Mobile Menu Toggle Button */}
              <div className="lg:hidden flex items-center">
                <button 
                  onClick={toggleMobileMenu} 
                  className="text-white hover:text-[hsl(var(--accent))] transition-colors focus:outline-none p-2"
                  aria-label="Toggle menu"
                >
                  {isMobileMenuOpen ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile Dropdown Menu */}
          {isMobileMenuOpen && (
            <div className="lg:hidden bg-black border-t border-[hsl(var(--accent))] px-4 pt-2 pb-6 space-y-2 shadow-xl max-h-[80vh] overflow-y-auto">
              <button onClick={() => scrollToSection('hero')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Home</button>
              <button onClick={() => scrollToSection('growth')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">The Problem</button>
              <button onClick={() => scrollToSection('what-we-build')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">What We Build</button>
              <button onClick={() => scrollToSection('how-we-work')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">How We Work</button>
              <button onClick={() => scrollToSection('philosophy')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Philosophy</button>
              <button onClick={() => scrollToSection('podcast')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Podcast</button>
              <button onClick={() => window.location.href='/affordable-housing-advisory'} className="w-full text-left block px-3 py-3 text-base font-medium text-[#4fd1c5] transition-colors duration-200 border-l-2 border-[#4fd1c5] pl-2">Housing Advisory</button>
              <button onClick={() => scrollToSection('contact')} className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Contact</button>
            </div>
          )}
        </nav>

        {/* Hero Section */}
        <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
          <div className="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1681201459745-bc9e4086b4bc" alt="Abstract geometric network pattern" className="w-full h-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/80 to-black"></div>
          </div>

          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-12 w-full">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="w-24 h-1 bg-[hsl(var(--accent))] mx-auto mb-8"></div>
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-8" style={{ letterSpacing: '-0.02em', textWrap: 'balance' }}>
                Build an Organization That Doesn't Require You to Carry Everything.
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl font-semibold mb-6 text-[hsl(var(--accent))] px-2 sm:px-0">
                Principal advisory for founder-led service businesses building stronger leadership, clearer ownership, and operating capacity beyond the founder.
              </p>
              <p className="text-base sm:text-lg md:text-xl max-w-3xl mx-auto mb-12 text-gray-300">
                Your company has grown. Your responsibilities have grown with it. Somewhere along the way, every important decision, every difficult problem, and every major interruption started flowing back to you. I help founder-led service businesses become organizations that can grow without requiring the founder to carry everything.
              </p>
              <p className="text-sm sm:text-base md:text-lg max-w-3xl mx-auto mb-12 text-gray-400">
                Together, we create stronger leadership, clearer ownership, better systems, and practical execution so the business can grow without pulling every important decision back to you.
              </p>
              <Button onClick={() => window.open('https://calendly.com/scott8smith/founder-strategy-conversation', '_blank', 'noopener,noreferrer')} className="mb-16 bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]/90 text-sm md:text-base px-4 md:px-8 py-4 md:py-6 font-bold transition-all duration-200 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal">
                <span className="flex items-center justify-center text-center">
                  SCHEDULE A FOUNDER STRATEGY CONVERSATION
                  <ArrowRight className="ml-2 h-5 w-5 flex-shrink-0" />
                </span>
              </Button>
            </motion.div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-px bg-[hsl(var(--accent))]"></div>
        </section>

        {/* Growth Changed the Rules */}
        <section id="growth" className="section-spacing bg-[hsl(var(--charcoal))] py-24 border-b border-gray-800">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-5xl font-bold mb-8" style={{ letterSpacing: '-0.02em' }}>
                Growth Changed the Rules
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                You probably started by doing everything yourself. <br/><br/>
                That worked.<br/><br/>
                Until it didn't. Now...
              </p>
              
              <ul className="space-y-4 mb-12">
                {[
                  "Your team still depends on you for too many decisions.",
                  "Hiring more people hasn't reduced your workload.",
                  "Every interruption feels urgent.",
                  "You're investing in software without creating meaningful leverage.",
                  "You know something has to change, but you're tired of buying solutions that don't solve the real problem."
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle2 className="h-6 w-6 text-[hsl(var(--accent))] mr-4 flex-shrink-0 mt-0.5" />
                    <span className="text-lg text-gray-300">{item}</span>
                  </li>
                ))}
              </ul>

              <div className="p-6 bg-black border-l-4 border-[hsl(var(--accent))]">
                <p className="text-xl font-semibold text-white">
                  Growth changed the rules. The leadership approach that built a five-person company rarely builds a twenty-five-person company.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* What I Help Build */}
        <section id="what-we-build" className="section-spacing bg-black py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-5xl font-bold mb-8" style={{ letterSpacing: '-0.02em' }}>
                What I Help Build
              </h2>
              <p className="text-lg text-gray-400 mb-2">I don't begin with software.</p>
              <p className="text-lg text-gray-400 mb-2">I don't begin with outsourcing.</p>
              <p className="text-lg text-gray-400 mb-8">I don't begin with AI.</p>
              
              <p className="text-2xl font-medium text-white mb-8">
                I begin by understanding how your business actually operates. Then we build:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                {[
                  "Clear ownership across the organization",
                  "Better decision flow",
                  "Leaders who carry responsibility",
                  "Systems that reduce founder dependence",
                  "Practical use of AI, automation, and global talent where they genuinely create leverage"
                ].map((item, index) => (
                  <div key={index} className="bg-[hsl(var(--charcoal))] p-6 rounded-sm border border-gray-800 flex items-start">
                    <div className="w-2 h-2 bg-[hsl(var(--accent))] mt-2.5 mr-4 flex-shrink-0"></div>
                    <span className="text-lg text-gray-200">{item}</span>
                  </div>
                ))}
              </div>

              <p className="text-xl text-[hsl(var(--accent))] font-medium italic">
                Every recommendation is based on what your business actually needs, not what's popular this year.
              </p>
            </motion.div>
          </div>
        </section>

        {/* How We Work */}
        <section id="how-we-work" className="section-spacing bg-[hsl(var(--charcoal))] py-24 border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4" style={{ letterSpacing: '-0.02em' }}>
                How We Work
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.1 }} className="bg-black p-10 border-t-4 border-[hsl(var(--accent))] relative">
                <div className="absolute -top-6 left-8 bg-[hsl(var(--accent))] text-white text-2xl font-bold w-12 h-12 flex items-center justify-center rounded-sm">1</div>
                <h3 className="text-2xl font-bold mb-4 mt-4">See the Organization Clearly</h3>
                <p className="text-gray-400 mb-4">
                  We examine how decisions, responsibility, and work actually flow through the business, not simply how the org chart says they should.
                </p>
                <p className="text-gray-400">
                  We identify where work slows down, decisions accumulate, and too much continues to return to the founder.
                </p>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.2 }} className="bg-black p-10 border-t-4 border-[hsl(var(--accent))] relative">
                <div className="absolute -top-6 left-8 bg-[hsl(var(--accent))] text-white text-2xl font-bold w-12 h-12 flex items-center justify-center rounded-sm">2</div>
                <h3 className="text-2xl font-bold mb-4 mt-4">Identify the Point of Dependence</h3>
                <p className="text-gray-400 mb-4">
                  Before spending money on another hire, platform, or consultant, we determine what is creating founder dependence and where the highest-leverage changes can be made.
                </p>
                <p className="text-gray-400 font-medium text-white">
                  The objective is not to add more activity. It is to remove unnecessary friction and clarify responsibility.
                </p>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.3 }} className="bg-black p-10 border-t-4 border-[hsl(var(--accent))] relative">
                <div className="absolute -top-6 left-8 bg-[hsl(var(--accent))] text-white text-2xl font-bold w-12 h-12 flex items-center justify-center rounded-sm">3</div>
                <h3 className="text-2xl font-bold mb-4 mt-4">Build Capacity Beyond the Founder</h3>
                <p className="text-gray-400">
                  Together, we implement the right combination of leadership structure, decision rights, operating systems, technology, and talent so the organization can carry more without becoming more dependent on the founder.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Leadership Before Tools */}
        <section className="section-spacing bg-black py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-8" style={{ letterSpacing: '-0.02em' }}>
                Leadership Before Tools
              </h2>
              <div className="text-xl text-gray-300 space-y-4 max-w-2xl mx-auto">
                <p>Many founders assume they need another employee.</p>
                <p>Or another software platform.</p>
                <p>Or another AI tool.</p>
                <p className="text-[hsl(var(--accent))] font-semibold mt-8 mb-8">Sometimes they do. Often they don't.</p>
                <p>The right solution isn't determined by what's available.</p>
                <p>It's determined by what your business actually needs.</p>
                <p className="text-white font-bold mt-8">That's where we begin.</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* My Philosophy */}
        <section id="philosophy" className="section-spacing bg-[hsl(var(--charcoal))] relative overflow-hidden py-24 border-t border-gray-800">
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="lg:col-span-5">
                <div className="relative">
                  <div className="absolute inset-0 bg-[hsl(var(--accent))] translate-x-4 translate-y-4 z-0"></div>
                  <img src="https://horizons-cdn.hostinger.com/73aa3b3a-1830-4109-8648-6c85653e3a08/e5e30b0b5ceb56afa5892f5dabdae6b3.png" alt="Scott Smith" className="relative z-10 w-full h-auto object-cover grayscale border border-gray-800" />
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="lg:col-span-7 space-y-8">
                <div>
                  <div className="w-16 h-1 bg-[hsl(var(--accent))] mb-6"></div>
                  <h2 className="text-3xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em', textWrap: 'balance' }}>
                    My Philosophy
                  </h2>
                  <p className="text-xl text-gray-300 mb-8">
                    Everything I do is grounded in principles that have endured for centuries.
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                    <div className="bg-black p-6 border-l-2 border-[hsl(var(--accent))]">
                      <div className="text-lg font-bold text-white uppercase tracking-wider">Clarity</div>
                      <div className="text-sm text-[hsl(var(--accent))] mt-1">under pressure</div>
                    </div>
                    <div className="bg-black p-6 border-l-2 border-[hsl(var(--accent))]">
                      <div className="text-lg font-bold text-white uppercase tracking-wider">Responsibility</div>
                      <div className="text-sm text-[hsl(var(--accent))] mt-1">without ego</div>
                    </div>
                    <div className="bg-black p-6 border-l-2 border-[hsl(var(--accent))]">
                      <div className="text-lg font-bold text-white uppercase tracking-wider">Disciplined</div>
                      <div className="text-sm text-[hsl(var(--accent))] mt-1">action</div>
                    </div>
                    <div className="bg-black p-6 border-l-2 border-[hsl(var(--accent))]">
                      <div className="text-lg font-bold text-white uppercase tracking-wider">Leadership</div>
                      <div className="text-sm text-[hsl(var(--accent))] mt-1">through character</div>
                    </div>
                  </div>

                  <p className="text-lg text-gray-300">
                    Stoicism isn't the product. It's the operating philosophy behind how I help founders make better decisions, build stronger organizations, and lead with confidence.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Podcast Section */}
        <section id="podcast" className="section-spacing bg-black py-24 border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16">
              <motion.div 
                initial={{ opacity: 0, y: 20 }} 
                whileInView={{ opacity: 1, y: 0 }} 
                viewport={{ once: true }} 
                transition={{ duration: 0.5 }}
                className="lg:col-span-8"
              >
                <span className="text-[hsl(var(--accent))] font-bold tracking-widest uppercase text-sm mb-4 flex items-center gap-2">
                  <Mic className="h-4 w-4" /> The Stoic Inner Strategy
                </span>
                <h2 className="text-3xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em' }}>
                  Leadership Insights
                </h2>
                <div className="text-xl text-gray-300 space-y-4 max-w-3xl">
                  <p>I believe better businesses begin with better leaders.</p>
                  <p>
                    That is why I host <em>The Stoic Inner Strategy</em>, a podcast exploring leadership, responsibility, decision-making, and character through the lens of Stoic philosophy and real-world experience.
                  </p>
                  <p>These are practical reflections for founders and leaders carrying the weight of responsibility.</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, x: 20 }} 
                whileInView={{ opacity: 1, x: 0 }} 
                viewport={{ once: true }} 
                transition={{ duration: 0.5, delay: 0.2 }}
                className="lg:col-span-4 flex items-end lg:justify-end"
              >
                <Button 
                  onClick={() => window.open('https://thestoicinnerstrategy.buzzsprout.com/', '_blank', 'noopener,noreferrer')} 
                  className="bg-transparent text-white border border-[hsl(var(--accent))] hover:bg-[hsl(var(--accent))] text-base px-8 py-6 font-bold transition-all duration-200 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal text-center"
                >
                  VIEW ALL EPISODES
                  <ArrowRight className="ml-2 h-5 w-5 inline" />
                </Button>
              </motion.div>
            </div>

            {!loadingPodcast && !podcastError && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {episodes.map((episode, index) => (
                  <motion.div 
                    key={episode.guid}
                    initial={{ opacity: 0, y: 20 }} 
                    whileInView={{ opacity: 1, y: 0 }} 
                    viewport={{ once: true }} 
                    transition={{ duration: 0.5, delay: index * 0.1 }} 
                    className="bg-[hsl(var(--charcoal))] rounded-sm border border-gray-800 hover:border-[hsl(var(--accent))] transition-colors duration-300 flex flex-col h-full overflow-hidden group"
                  >
                    <div className="relative aspect-video overflow-hidden bg-black border-b border-gray-800">
                      <img 
                        src={episode.thumbnail || 'https://i.postimg.cc/fRNhKJFC/logo.png'} 
                        alt={episode.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <PlayCircle className="h-16 w-16 text-[hsl(var(--accent))]" />
                      </div>
                    </div>
                    <div className="p-8 flex flex-col flex-grow">
                      <span className="text-sm text-gray-500 font-medium mb-3">
                        {formatDate(episode.pubDate)}
                      </span>
                      <h3 className="text-xl font-bold mb-4 text-white line-clamp-2 leading-tight">
                        {episode.title}
                      </h3>
                      <p className="text-gray-400 mb-8 flex-grow">
                        {formatDescription(episode.description)}
                      </p>
                      <button 
                        onClick={() => window.open(episode.link, '_blank', 'noopener,noreferrer')}
                        className="flex items-center text-[hsl(var(--accent))] font-bold hover:text-white transition-colors duration-200 mt-auto"
                      >
                        LISTEN TO EPISODE
                        <PlayCircle className="ml-2 h-5 w-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
            
            {loadingPodcast && (
              <div className="flex justify-center items-center py-20">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[hsl(var(--accent))]"></div>
              </div>
            )}
            
            {podcastError && (
              <div className="bg-[hsl(var(--charcoal))] p-8 border border-gray-800 rounded-sm text-center">
                <p className="text-gray-400 mb-4">We're currently updating our podcast feed.</p>
                <Button 
                  onClick={() => window.open('https://thestoicinnerstrategy.buzzsprout.com/', '_blank', 'noopener,noreferrer')} 
                  className="bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]/90"
                >
                  LISTEN DIRECTLY ON BUZZSPROUT
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* Affordable Housing & Public Funding Advisory */}
        <section id="housing-advisory" className="section-spacing bg-[#f8fafc] text-[#0f172a] py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="max-w-3xl">
              <span className="text-[#0a4e53] font-bold uppercase tracking-widest text-sm mb-4 block">
                Public-Sector Partnership
              </span>
              <h2 className="text-3xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em', textWrap: 'balance' }}>
                Affordable Housing & Public Funding Advisory
              </h2>
              <p className="text-lg md:text-xl text-[#334155] mb-6 leading-relaxed font-semibold">
                Akhada Consulting also provides specialized affordable housing and public-funding advisory through its public-sector practice.
              </p>
              <p className="text-lg md:text-xl text-[#334155] mb-6 leading-relaxed">
                Affordable housing development requires more than a viable property and a strong financial plan. Developers must also navigate public funding programs, government priorities, agency requirements, and community interests.
              </p>
              <p className="text-base md:text-lg text-[#475569] mb-10 leading-relaxed">
                Akhada Consulting helps affordable housing developers and organizations understand the public-sector landscape, identify viable funding and partnership opportunities, and move complex housing initiatives forward.
              </p>
              <Button onClick={() => window.location.href='/affordable-housing-advisory'} className="bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]/90 text-sm md:text-base px-6 md:px-8 py-4 md:py-6 font-bold transition-all duration-200 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal">
                <span className="flex items-center justify-center text-center">
                  EXPLORE AFFORDABLE HOUSING ADVISORY
                  <ArrowRight className="ml-2 h-5 w-5 flex-shrink-0" />
                </span>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Let's Talk CTA */}
        <section className="section-spacing bg-black py-24 text-center">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Let's Talk</h2>
              <p className="text-xl text-gray-300 mb-8">
                If you're leading a growing service business and feel like too much still depends on you, let's start with a conversation.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-gray-400 mb-6">
                <span>✓ No generic diagnosis.</span>
                <span className="hidden sm:inline">•</span>
                <span>✓ No predetermined solution.</span>
                <span className="hidden sm:inline">•</span>
                <span>✓ Just a candid conversation about what the business requires next.</span>
              </div>
              <p className="text-lg text-gray-400 mb-10 max-w-2xl mx-auto">
                In this conversation, we will identify where decisions and responsibility are concentrating around you and determine what must change next.
              </p>
              <Button onClick={() => window.open('https://calendly.com/scott8smith/founder-strategy-conversation', '_blank', 'noopener,noreferrer')} className="bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]/90 text-sm md:text-lg px-4 md:px-10 py-4 md:py-7 font-bold transition-all duration-200 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal text-center">
                SCHEDULE A FOUNDER STRATEGY CONVERSATION
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer id="contact" className="bg-black border-t border-[hsl(var(--accent))] py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
              <div>
                <div className="text-xl font-bold mb-4 tracking-wider">AKHADA</div>
                <p className="text-sm text-gray-400 max-w-sm">
                  Principal advisory for founder-led service businesses building stronger leadership, clearer ownership, and operating capacity beyond the founder.
                </p>
              </div>
              <div>
                <h4 className="text-sm font-bold mb-4 uppercase tracking-wider">Contact</h4>
                <div className="space-y-2 text-sm text-gray-400">
                  <p>scott.smith@akhadaconsulting.com</p>
                  <p>+1 (602) 492-1333</p>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold mb-4 uppercase tracking-wider">Connect</h4>
                <div className="flex gap-4">
                  <a href="https://www.linkedin.com/in/scott8smith/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[hsl(var(--accent))] transition-colors duration-200 font-medium">LinkedIn</a>
                  <a href="https://x.com/Akhada_Consult" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[hsl(var(--accent))] transition-colors duration-200 font-medium">X</a>
                </div>
              </div>
            </div>
            <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
              <p>© {new Date().getFullYear()} AKHADA. All rights reserved.</p>
              <div className="flex gap-6">
                <a href="#" className="hover:text-[hsl(var(--accent))] transition-colors duration-200">Privacy Policy</a>
                <a href="#" className="hover:text-[hsl(var(--accent))] transition-colors duration-200">Terms of Service</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default HomePage;