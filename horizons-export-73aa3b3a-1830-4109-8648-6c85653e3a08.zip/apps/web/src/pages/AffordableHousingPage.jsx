import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2, Landmark, Users, Briefcase, FileText, ShieldCheck, Target, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AffordableHousingPage = () => {
  // Add state to track if the mobile menu is open or closed
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Helper functions to handle opening and closing the menu
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <Helmet>
        <title>Affordable Housing & Public Funding Advisory | Akhada Consulting</title>
        <meta name="description" content="Akhada Consulting helps affordable housing developers and organizations navigate public funding, government agencies, program requirements, and public-sector partnerships." />
        {/* ADD YOUR FAVICON DIRECT LINK BELOW */}
        <link rel="icon" type="image/png" href="YOUR_FAVICON_URL_HERE" />
      </Helmet>

      <div className="bg-black text-white font-sans overflow-x-hidden w-full">
        {/* Navigation */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-[hsl(var(--accent))]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <a href="/" className="flex items-center gap-3">
                  <img src="https://i.postimg.cc/fRNhKJFC/logo.png" alt="AKHADA Logo" className="h-12 w-auto object-contain" />
                  <span className="text-xl font-bold tracking-wider text-white hidden sm:block">AKHADA</span>
                </a>
              </div>
              
              {/* Desktop Menu (Hidden on mobile) */}
              <div className="hidden md:flex items-center gap-8">
                <a href="/" className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200">Home</a>
                <a href="/affordable-housing-advisory" className="text-sm font-medium text-white border-b-2 border-[hsl(var(--accent))] pb-1 transition-colors duration-200">Housing Advisory</a>
                <button 
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                  }} 
                  className="text-sm font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200"
                >
                  Contact
                </button>
              </div>

              {/* Mobile Menu Toggle Button (Visible only on mobile) */}
              <div className="md:hidden flex items-center">
                <button 
                  onClick={toggleMobileMenu} 
                  className="text-white hover:text-[hsl(var(--accent))] transition-colors focus:outline-none p-2"
                  aria-label="Toggle menu"
                >
                  {isMobileMenuOpen ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile Dropdown Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-black border-t border-[hsl(var(--accent))] px-4 pt-2 pb-6 space-y-2 shadow-xl">
              <a 
                href="/" 
                onClick={closeMobileMenu} 
                className="block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200"
              >
                Home
              </a>
              <a 
                href="/affordable-housing-advisory" 
                onClick={closeMobileMenu} 
                className="block px-3 py-3 text-base font-medium text-[hsl(var(--accent))] transition-colors duration-200"
              >
                Housing Advisory
              </a>
              <button 
                onClick={(e) => {
                  e.preventDefault();
                  closeMobileMenu(); // Close menu before scrolling
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="w-full text-left block px-3 py-3 text-base font-medium hover:text-[hsl(var(--accent))] transition-colors duration-200"
              >
                Contact
              </button>
            </div>
          )}
        </nav>

        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden pt-20 pb-16">
          <div className="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab" alt="Building architecture" className="w-full h-full object-cover opacity-20 grayscale" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black to-black"></div>
          </div>

          <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-12 w-full">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="w-24 h-1 bg-[hsl(var(--accent))] mx-auto mb-8"></div>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight mb-8" style={{ letterSpacing: '-0.02em', textWrap: 'balance' }}>
                Navigate Government. Advance Affordable Housing.
              </h1>
              <p className="text-lg md:text-xl max-w-3xl mx-auto mb-12 text-gray-300 leading-relaxed">
                Akhada Consulting helps affordable housing developers and organizations navigate public funding programs, government agencies, program requirements, and public-sector partnerships.
              </p>
              <Button 
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="mb-8 bg-[hsl(var(--accent))] text-white hover:bg-[#0a4e53] text-sm md:text-base px-6 md:px-10 py-4 md:py-7 font-bold transition-colors duration-300 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal"
              >
                <span className="flex items-center justify-center text-center">
                  DISCUSS A HOUSING INITIATIVE
                  <ArrowRight className="ml-2 h-5 w-5 flex-shrink-0" />
                </span>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* The Challenge */}
        <section className="section-spacing bg-[hsl(var(--charcoal))] py-24 border-b border-gray-800">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-8" style={{ letterSpacing: '-0.02em' }}>
                The Intersection of Development and Public Policy
              </h2>
              <div className="p-8 bg-black border-l-4 border-[hsl(var(--accent))] text-lg md:text-xl text-gray-300 leading-relaxed shadow-lg mb-8">
                <p>
                  Strong affordable housing projects can stall when developers lack clarity about public funding, agency requirements, government priorities, or the right path through the public-sector process. Akhada Consulting helps clients understand the landscape, engage the right stakeholders, and move viable initiatives forward.
                </p>
              </div>
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
                Public programs are not difficult merely because the rules are complex. They are difficult because funding, policy, agency priorities, documentation, timing, and stakeholder interests must all align. Akhada Consulting helps clients understand that full landscape and move through it deliberately.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Who We Serve */}
        <section className="section-spacing bg-black py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-12" style={{ letterSpacing: '-0.02em' }}>
                Who We Serve
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-left">
                {[
                  "Affordable housing developers",
                  "Multifamily developers exploring affordable or workforce housing",
                  "Nonprofit housing organizations",
                  "Municipalities, counties, and housing authorities",
                  "Public-private housing partnerships",
                  "Professional-services organizations needing public-sector housing expertise"
                ].map((item, index) => (
                  <div key={index} className="bg-[hsl(var(--charcoal))] p-6 rounded-sm border border-gray-800 flex items-start">
                    <CheckCircle2 className="h-6 w-6 text-[hsl(var(--accent))] mr-4 flex-shrink-0 mt-0.5" />
                    <span className="text-lg text-gray-200">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* How We Help */}
        <section className="section-spacing bg-[hsl(var(--charcoal))] py-24 border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{ letterSpacing: '-0.02em' }}>
                How We Help
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Category 1 */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.1 }} className="bg-black p-8 md:p-10 border-t-4 border-[hsl(var(--accent))]">
                <Landmark className="h-10 w-10 text-[hsl(var(--accent))] mb-6" />
                <h3 className="text-2xl font-bold mb-4">Clarify Funding Paths</h3>
                <p className="text-gray-400 mb-6">Identify relevant programs, eligibility considerations, public agencies, funding requirements, and viable public-sector opportunities.</p>
                <ul className="space-y-4">
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-[hsl(var(--accent))] rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Public funding opportunity and eligibility assessment</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-[hsl(var(--accent))] rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">LIHTC agency, process, and public-sector navigation</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-[hsl(var(--accent))] rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">HUD, HOME, CDBG, and related program guidance</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-[hsl(var(--accent))] rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">State and local housing funding assessment</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-[hsl(var(--accent))] rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Application coordination, proposal support, and public-funding strategy</span></li>
                </ul>
              </motion.div>

              {/* Category 2 */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.2 }} className="bg-black p-8 md:p-10 border-t-4 border-gray-500">
                <Users className="h-10 w-10 text-gray-400 mb-6" />
                <h3 className="text-2xl font-bold mb-4">Navigate Government</h3>
                <p className="text-gray-400 mb-6">Interpret public processes, coordinate stakeholders, and support productive engagement with municipal, county, state, and federal agencies.</p>
                <ul className="space-y-4">
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Municipal, county, state, and federal agency engagement</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Government process and requirement interpretation</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Stakeholder identification and coordination</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Public-sector communication strategy</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Navigation of agency priorities and administrative processes</span></li>
                </ul>
              </motion.div>

              {/* Category 3 */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.3 }} className="bg-black p-8 md:p-10 border-t-4 border-gray-500">
                <Briefcase className="h-10 w-10 text-gray-400 mb-6" />
                <h3 className="text-2xl font-bold mb-4">Structure Partnerships</h3>
                <p className="text-gray-400 mb-6">Align developers, public agencies, nonprofits, professional partners, and community interests around a viable path forward.</p>
                <ul className="space-y-4">
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Early-stage housing opportunity assessment</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Public-private partnership strategy</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Alignment with government and community priorities</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Partner and resource identification</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Strategic support for affordable and workforce housing initiatives</span></li>
                </ul>
              </motion.div>

              {/* Category 4 */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.4 }} className="bg-black p-8 md:p-10 border-t-4 border-gray-500">
                <FileText className="h-10 w-10 text-gray-400 mb-6" />
                <h3 className="text-2xl font-bold mb-4">Support Implementation</h3>
                <p className="text-gray-400 mb-6">Assist with program administration, implementation planning, documentation, reporting, compliance-process coordination, and stakeholder communication.</p>
                <ul className="space-y-4">
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Housing program design and administration</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Implementation planning</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Reporting and documentation support</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Compliance-process coordination</span></li>
                  <li className="flex items-start"><div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2.5 mr-3 flex-shrink-0"></div><span className="text-gray-300">Cross-agency and stakeholder coordination</span></li>
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Our Approach */}
        <section className="section-spacing bg-black py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-16" style={{ letterSpacing: '-0.02em' }}>
                Our Approach
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="p-6">
                  <Target className="h-12 w-12 text-[hsl(var(--accent))] mx-auto mb-6" />
                  <h3 className="text-xl font-bold mb-4 text-white">Assess</h3>
                  <p className="text-gray-400">
                    Clarify the opportunity, stakeholders, public resources, constraints, and desired outcome.
                  </p>
                </div>
                <div className="p-6">
                  <ShieldCheck className="h-12 w-12 text-gray-400 mx-auto mb-6" />
                  <h3 className="text-xl font-bold mb-4 text-white">Align</h3>
                  <p className="text-gray-400">
                    Connect development objectives with government priorities, program requirements, community interests, and viable partnerships.
                  </p>
                </div>
                <div className="p-6">
                  <ArrowRight className="h-12 w-12 text-gray-400 mx-auto mb-6" />
                  <h3 className="text-xl font-bold mb-4 text-white">Advance</h3>
                  <p className="text-gray-400">
                    Develop a practical path forward and provide support through coordination, applications, implementation planning, and program administration as appropriate.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ARPA Support */}
        <section className="section-spacing bg-[hsl(var(--charcoal))] py-16 border-y border-gray-800">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="bg-black p-8 rounded-sm border border-gray-800">
              <h3 className="text-xl md:text-2xl font-bold mb-4 text-white">Current Capability: ARPA Housing Implementation and Closeout Support</h3>
              <p className="text-gray-300 leading-relaxed">
                As the ARPA funding lifecycle approaches its conclusion, public agencies and partner organizations may still need support coordinating implementation, documentation, reporting, expenditures, and closeout activities for obligated housing initiatives. Akhada Consulting provides strategic and administrative support to help organizations complete this work responsibly.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Practice Leadership */}
        <section className="section-spacing bg-black py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="flex flex-col md:flex-row items-center gap-10">
              <div className="w-48 h-48 md:w-64 md:h-64 flex-shrink-0 bg-gray-900 rounded-full overflow-hidden border-2 border-[hsl(var(--accent))]">
                <img src="https://i.postimg.cc/ZCVTY9fV/your-photo.jpg" alt="Robin Smith" className="w-full h-full object-cover grayscale" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Affordable Housing Practice Leadership</h2>
                <div className="w-16 h-1 bg-[hsl(var(--accent))] mb-6"></div>
                <p className="text-lg text-gray-300 leading-relaxed">
                  Akhada Consulting’s affordable housing practice is led by Robin Smith, whose experience includes state and county government, affordable housing administration, rental housing development programs, public funding, community partnerships, and collaboration with developers, nonprofits, and public agencies.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="section-spacing bg-[hsl(var(--charcoal))] py-24 text-center border-t border-gray-800">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Move Your Housing Initiative Forward</h2>
              <p className="text-xl text-gray-300 mb-10">
                Whether you are evaluating an opportunity, navigating a public funding program, engaging government stakeholders, or advancing an active housing initiative, Akhada Consulting can help clarify the path forward.
              </p>
              <Button 
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="bg-[hsl(var(--accent))] text-white hover:bg-[#0a4e53] text-sm md:text-lg px-6 md:px-10 py-4 md:py-7 font-bold transition-colors duration-300 active:scale-[0.98] w-full sm:w-auto h-auto whitespace-normal"
              >
                DISCUSS A HOUSING INITIATIVE
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer id="contact" className="bg-black border-t border-[hsl(var(--accent))] py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
              <div>
                <div className="text-xl font-bold mb-4 tracking-wider">AKHADA</div>
                <p className="text-sm text-gray-400 max-w-sm">
                  Affordable housing and public-funding advisory for developers, organizations, and public-sector partners.
                </p>
              </div>
              <div>
                <h4 className="text-sm font-bold mb-4 uppercase tracking-wider">Contact</h4>
                <div className="space-y-2 text-sm text-gray-400">
                  <p>robin.smith@akhadaconsulting.com</p>
                  <p>+1 (480) 809-5511</p>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold mb-4 uppercase tracking-wider">Connect</h4>
                <div className="flex gap-4">
                  <a href="https://www.linkedin.com/in/robin-smith-9411771a3/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[hsl(var(--accent))] transition-colors duration-200 font-medium">LinkedIn</a>
                  <a href="https://x.com/Akhada_Consult" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[hsl(var(--accent))] transition-colors duration-200 font-medium">X</a>
                </div>
              </div>
            </div>
            <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
              <p>© {new Date().getFullYear()} Akhada Consulting LLC. All rights reserved.</p>
              <div className="flex gap-6">
                <a href="#" className="hover:text-[hsl(var(--accent))] transition-colors duration-200">Privacy Policy</a>
                <a href="#" className="hover:text-[hsl(var(--accent))] transition-colors duration-200">Terms of Service</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default AffordableHousingPage;