import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import HomePage from './pages/HomePage.jsx';
import AffordableHousingPage from './pages/AffordableHousingPage.jsx';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/affordable-housing-advisory" element={<AffordableHousingPage />} />
      </Routes>
    </Router>
  );
}

export default App;